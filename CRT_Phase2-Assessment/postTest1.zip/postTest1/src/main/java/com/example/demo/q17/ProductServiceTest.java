package com.example.demo.q17;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class ProductServiceTest {

    @Mock
    ProductRepository repo;

    @InjectMocks
    ProductService service;

    @Test
    public void testGetById() {

        Product p = new Product();
        p.setId(1L);
        p.setName("Laptop");

        when(repo.findById(1L)).thenReturn(Optional.of(p));

        Product result = service.getById(1L);

        assertEquals("Laptop", result.getName());
    }
}
