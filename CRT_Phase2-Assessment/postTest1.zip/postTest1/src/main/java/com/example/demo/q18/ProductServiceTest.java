package com.example.demo.q18;

package com.example.demo.q18;

import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

@SpringBootTest
public class ProductServiceTest {

    @MockBean
    ProductRepository repo;

    @Autowired
    ProductService service;

    @Test
    public void testMethod() {

        when(repo.count()).thenReturn(5L);

        System.out.println(service);
    }
}
