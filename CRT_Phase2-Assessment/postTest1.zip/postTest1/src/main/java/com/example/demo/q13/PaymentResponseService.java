package com.example.demo.q13;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@Service
public class PaymentResponseService {
	@Autowired
	    RestTemplate restTemplate;

	    @CircuitBreaker(name = "paymentService", fallbackMethod = "paymentFallback")
	    public PaymentResponse getPayment() {

	        return restTemplate.getForObject(
	                "http://localhost:8081/payment",
	                PaymentResponse.class);
	    }

	    public PaymentResponse paymentFallback(Exception e) {

	        PaymentResponse response = new PaymentResponse();
	        response.setStatus("Payment Service Down");

	        return response;
	    }
	}
