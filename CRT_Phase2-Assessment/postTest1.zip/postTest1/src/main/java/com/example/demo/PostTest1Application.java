package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PostTest1Application {

	public static void main(String[] args) {
		SpringApplication.run(PostTest1Application.class, args);
	}

}
